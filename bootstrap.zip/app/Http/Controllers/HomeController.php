<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subscription;
use App\Models\user;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    
    { 

        if($request->q){
           $response = $this->fetch('https://api.companieshouse.gov.uk/search/companies','GET',['q'=>$request->q]);
           $data['total_results'] = $response->total_results;
           $data['page_number'] = $response->page_number;
           $data['items_per_page'] = $response->items_per_page;
           if($response->items){
               foreach($response->items as $key => $item){
                    $companyNumber = $item->company_number;
                    $appointmentResponse = $this->fetch("https://api.company-information.service.gov.uk/company/$companyNumber/officers",'GET',[]);
                    $response->items[$key]->total_appointment = $appointmentResponse->total_results;
               }
           }
           $data['companies'] = $response->items;
        }
        $data['companies'] = $data['companies'] ?? array();
        return view('welcome',$data);
    }

    public function appointment($companyNumber){
        $companyResponse = $this->fetch("https://api.companieshouse.gov.uk/company/$companyNumber",'GET',[]);
        $appointmentResponse = $this->fetch("https://api.companieshouse.gov.uk/company/$companyNumber/officers",'GET',[]);
        $data['company']     = $companyResponse;
        $data['appointment'] = $appointmentResponse;
        return view('appointment',$data);
    }

    public function profile(){
        $data['user']         = User::find(Auth::id());
        $data['subscription'] = Subscription::where('user_id',Auth::id())->orderBy('id','desc')->first();
        return view('profile.index',$data);
    }

    public function fetch($url,$method,$params){


            $params = http_build_query($params);
            $url = $url."?".$params;
    
            $curl = curl_init();
    
            $arr = array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => $method,
              CURLOPT_HTTPHEADER => array(
                "authorization: 4d7c5b9d-3ff3-472d-80a7-3e44cee9563d",
                "content-type: application/json",
                "accept: application/json",
              )
            );
    
            curl_setopt_array($curl, $arr);
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
                   return $err;
            } else {
              return json_decode($response);
            }
     }      
}
