<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/officers/{companyNumber}/appointments', [App\Http\Controllers\HomeController::class, 'appointment'])->name('appointment');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/profile', [App\Http\Controllers\HomeController::class, 'profile'])->name('profile');

Route::get('/plans', [App\Http\Controllers\PlanController::class, 'index'])->name('plan.index');
Route::get('/plan/details/{id}', [App\Http\Controllers\PlanController::class, 'show'])->name('plan.show');

Route::get('/subscription/cancel/{id}', [App\Http\Controllers\PaymentController::class, 'subscriptionCancel'])->name('subscription.cancel');

Route::get('/buy/now/{id}', [App\Http\Controllers\PaymentController::class, 'buyNow'])->name('payment.buyNow');
Route::get('/gocardless/host/mandate/success', [App\Http\Controllers\PaymentController::class, 'mandateSuccess'])->name('payment.mandateSuccess');

// Route::get('/gocardless/list', [App\Http\Controllers\GoCardLessController::class, 'list']);
// Route::get('/gocardless/subscribe', [App\Http\Controllers\GoCardLessController::class, 'subscribe']);
// Route::get('/gocardless/mandate', [App\Http\Controllers\GoCardLessController::class, 'mandate']);
// Route::get('/gocardless/create/customer', [App\Http\Controllers\GoCardLessController::class, 'createCustomer']);
// Route::get('/gocardless/create/bank/account', [App\Http\Controllers\GoCardLessController::class, 'createBankAccount']);

// Route::get('/gocardless/host/mandate', [App\Http\Controllers\GoCardLessController::class, 'hostMandate']);
// Route::get('/gocardless/host/mandate/success', [App\Http\Controllers\GoCardLessController::class, 'hostMandateSuccess']);