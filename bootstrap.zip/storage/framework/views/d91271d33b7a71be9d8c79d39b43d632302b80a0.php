<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 justify-content-center text-center">
            <form role="form" method="get">
              <div class="form-group">
                <h3 class="text-center">Enter company name, number or officer name</h3>
                <input type="text" name="q" value="<?php echo e(Request::get('q')); ?>" placeholder="Comany Name,Pearson Name" class="form-control" />
              </div>
              <input type="submit" value="<?php echo e(__('Search')); ?>" class="btn btn-success" />
            </form>
        </div>
    </div>
    <br>
    <?php if(Request::get('q')): ?>
    <div class="row justify-content-center">
      <div class="col-md-10">
         <table class="table">
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td>
                     <a href="<?php echo e(route('appointment',$company->company_number)); ?>"><?php echo e($company->title); ?></a><br/>
                     <small>Total number of appointments <?php echo e($company->total_appointment); ?> - Born <?php echo e(date('M Y',strtotime($company->date_of_creation))); ?></small><br/>
                     <small><?php echo e($company->address_snippet); ?></small><br/>
                     </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <tr>
                   <td><?php echo e(__('Record not found')); ?></td>
                 </tr>
              <?php endif; ?>
            </tbody>
         </table>
          <nav aria-label="Page navigation example">
          <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#">Previous</a></li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">Next</a></li>
          </ul>
        </nav>
      </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\cityfundingitd\resources\views/welcome.blade.php ENDPATH**/ ?>