
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
       <div class="col-md-12">
           <?php if(Session::get('message')): ?>
            <div class="alert alert-<?php echo e(Session::get('status') ? 'success' : 'danger'); ?>" role="alert">
              <?php echo e(Session::get('message')); ?>

            </div>
           <?php endif; ?>
       </div>
    </div>
    <div class="row">
       <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($plan->title); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"> £ <?php echo e($plan->monthly); ?> / Monthly</h6>
                    <h6 class="card-subtitle mb-2 text-muted"> £ <?php echo e($plan->yearly); ?> / yearly</h6>
                     <hr>
                    <h6 class="card-subtitle mb-2 text-muted"> <?php echo e($plan->property); ?> Property</h6>
                    <a href="<?php echo e(route('payment.buyNow',$plan->id)); ?>" class="card-link">Buy now</a>
                </div>
            </div>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
 <style>
    .card{
        margin : 10px auto;
    }
 </style>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\cityfundingitd\resources\views/plan/index.blade.php ENDPATH**/ ?>