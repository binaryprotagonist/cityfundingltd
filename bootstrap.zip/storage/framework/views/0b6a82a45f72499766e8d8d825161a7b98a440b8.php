
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
       <div class="col-md-12">
         <h1>Lorem Ipsum</h1>
       </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
 <style>
  
 </style>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\cityfundingitd\resources\views/plan/show.blade.php ENDPATH**/ ?>