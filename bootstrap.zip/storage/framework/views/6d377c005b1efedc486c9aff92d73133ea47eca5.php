

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 justify-content-center text-center">
            <form role="form" method="get">
              <div class="form-group">
                <h3 class="text-center">Enter company name, number or officer name</h3>
                <input type="text" name="q" value="<?php echo e(Request::get('q')); ?>" placeholder="Comany Name,Pearson Name" class="form-control" />
              </div>
              <input type="submit" value="<?php echo e(__('Search')); ?>" class="btn btn-success" />
            </form>
        </div>
    </div>
    <br>
    <div class="row justify-content-center">
      <div class="col-md-10">
        <h1><?php echo e($company->company_name); ?></h1>
        <h5>Total Number Of Appointment : <?php echo e($appointment->total_results); ?></h5>
        <p>Date Of Birth : <?php echo e(date('D Y',strtotime($company->date_of_creation))); ?></p>
        <?php $__currentLoopData = $appointment->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
               <h4><a href="javascript:void(0)"><?php echo e($item->name); ?></a></h4>
               <p>Appointment On <?php echo e($item->appointed_on); ?></p>
               <p>Role <?php echo e($item->officer_role); ?></p>
               <p>Appointment On <?php echo e($item->appointed_on); ?></p>
               <p>Appointment On <?php echo e($item->appointed_on); ?></p>
               <p>Appointment On <?php echo e($item->appointed_on); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\cityfundingitd\resources\views/appointment.blade.php ENDPATH**/ ?>