

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
       <div class="col-md-12">
           <?php if(Session::get('message')): ?>
            <div class="alert alert-<?php echo e(Session::get('status') ? 'success' : 'danger'); ?>" role="alert">
              <?php echo e(Session::get('message')); ?>

            </div>
           <?php endif; ?>
       </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Profile')); ?></div>
                <div class="card-body">
                    <p><b>Name</b>  : <?php echo e($user->name); ?></p>
                    <p><b>Email</b> : <?php echo e($user->email); ?></p>
                    <p><b>Address</b>  : <?php echo e($user->address); ?></p>
                    <p><b>City</b> : <?php echo e($user->city); ?></p>
                    <p><b>Postal Code</b> : <?php echo e($user->postal_code); ?></p>
                </div>
            </div>
            <br/>
            <div class="card">
                <div class="card-header"><?php echo e(__('Subscribed Plan')); ?></div>
                <div class="card-body">
                   <?php if($subscription): ?>
                        <p><b>Plan Id</b>  : #PlANID<?php echo e($subscription->plan_id); ?></p>
                        <p><b>Subscription Id</b> : #<?php echo e($subscription->subscription_id); ?></p>
                        <p><b>Plan Title</b>  : <?php echo e($subscription->plan_title); ?></p>
                        <p><b>Plan Property</b> : <?php echo e($subscription->plan_property); ?></p>
                        <p><b>Plan Status</b> : <?php echo e($subscription->subscription_status == '1' ? 'Activated' : 'Cancelled'); ?></p>
                        <p><b>Active Date</b> : <?php echo e(date('Y-M-d',strtotime($subscription->created_at))); ?></p>
                        <a href="<?php echo e(route('subscription.cancel',$subscription->id)); ?>">Cancel Subscription</a>
                   <?php else: ?>
                     <h3><?php echo e(__('You have no any active plan')); ?></h3>
                   <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\cityfundingitd\resources\views/profile/index.blade.php ENDPATH**/ ?>